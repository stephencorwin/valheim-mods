# Comfort Calculation Fix Valheim Plugin

## Features
Rewritten Comfort Logic

## Pre-Requisites
This mod requires BepInEx. Follow the instructions here if you don't have it installed already: https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/

## Dependencies
denikson-BepInExPack_Valheim-5.4.800