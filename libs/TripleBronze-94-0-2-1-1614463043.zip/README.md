# TripleBronze
Triples the amount of bronze you get with each craft so that crafting bronze is consistent (1 tin ingot + 2 copper ingots = 3 bronze ingots)
Place `.dll` file in to Valheim/BepinEx/plugins/ folder.
Requires BepinEx.

There is a configuration file to change the multiplier of bronze. After the first run, this file will be automatically created at "BepinEx/config/LolmanXDXD.TripleBronze.cfg"

In the configuration file, you can also enable the "QuickSmelt" patch which add QOL recipes from ores -> bars into the forge after upgrading the tier. This has configurable coal amounts. This might need you to drop/pickup coal ore, tin ore, wood, and iron ore.

Hosted at <https://www.nexusmods.com/valheim/mods/94>